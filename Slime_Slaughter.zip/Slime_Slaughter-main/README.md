# Slime_Slaughter

- Zum Spiel: [Slime_Slaughter](https://jonnyre.github.io/Slime_Slaughter/Code/Endabgabe/LevelSelect/LevelSelect.html)<br/>
- Zu den Code-Files: [Code Files-Folder](https://github.com/Jonnyre/Slime_Slaughter/tree/main/Code)<br/>
- Designdokument: [Zum Dokument](https://github.com/Jonnyre/Slime_Slaughter/blob/main/Designdokument.pdf)<br/>
- Zip-Download [hier](https://github.com/Jonnyre/Slime_Slaughter/blob/main/Slime_Slaughter.zip)
- Das Projekt muss lediglich mittels Live-Server ausgeführt werden. Die auszuführende html ist die Endabgabe/LevelSelect/LevelSelect.html.

Abgabe wurde mit Fudge erstellt im Rahmen des WPM Prototyping interaktiver Medien-Apps und Games der Hochschule Furtwangen.<br/>
Zum Repo des WPMs: [PRIMA](https://github.com/JirkaDellOro/Prima)